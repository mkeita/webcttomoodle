<?php
class WebCTRestore {
	
	
	public function __construct(){
		
	}
	
	
}